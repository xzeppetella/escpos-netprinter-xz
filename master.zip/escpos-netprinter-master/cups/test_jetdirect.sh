#!/bin/bash
# This is a script to test the jetdirect backend
python3 ./test_jetdirect.py