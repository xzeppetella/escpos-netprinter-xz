<?php

namespace ReceiptPrintHq\EscposTools\Parser\Context;

/**
 *
 */
interface ParserContext
{

    public function getProfile();
}
