<?php
namespace ReceiptPrintHq\EscposTools\Parser\Command;

use ReceiptPrintHq\EscposTools\Parser\Command\Code2DSubCommand;

class UnimplementedCode2DSubCommand extends Code2DSubCommand
{

}
