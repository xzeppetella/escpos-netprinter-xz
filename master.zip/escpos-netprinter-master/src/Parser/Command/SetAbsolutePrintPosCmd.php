<?php
namespace ReceiptPrintHq\EscposTools\Parser\Command;

use ReceiptPrintHq\EscposTools\Parser\Command\CommandTwoArgs;

class SetAbsolutePrintPosCmd extends CommandTwoArgs
{

}
