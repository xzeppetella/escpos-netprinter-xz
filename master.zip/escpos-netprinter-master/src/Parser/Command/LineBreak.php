<?php
namespace ReceiptPrintHq\EscposTools\Parser\Command;

interface LineBreak
{
}
