<?php
namespace ReceiptPrintHq\EscposTools\Parser\Command;

use ReceiptPrintHq\EscposTools\Parser\Command\EscposCommand;
use ReceiptPrintHq\EscposTools\Parser\Command\LineBreak;

class LineFeedCmd extends EscposCommand implements LineBreak
{

}
