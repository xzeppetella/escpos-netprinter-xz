<?php
namespace ReceiptPrintHq\EscposTools\Parser\Command;

use ReceiptPrintHq\EscposTools\Parser\Command\Command;
use ReceiptPrintHq\EscposTools\Parser\Command\DataSubCmd;

class PrintBufferredDataGraphicsSubCmd extends DataSubCmd
{

}
